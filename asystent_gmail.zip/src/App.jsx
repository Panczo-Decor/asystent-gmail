
import React from 'react';

function App() {
  const handleReply = () => {
    alert("Wiadomość została zarchiwizowana i wysłana!");
  };

  return (
    <div style={{ padding: '2rem', fontFamily: 'Arial' }}>
      <h1>Asystent Gmail</h1>
      <p>Temat: Nowe zamówienie z Allegro</p>
      <p>Treść: Klient zapytał o czas realizacji zamówienia.</p>
      <button onClick={handleReply} style={{ padding: '0.5rem 1rem', marginTop: '1rem' }}>
        Odpowiedz i Archiwizuj
      </button>
    </div>
  );
}

export default App;
